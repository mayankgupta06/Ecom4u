<?php
$N=$_POST["name"];
$UN=$_POST["uname"];
$M=$_POST["email"];
$P=$_POST["phone"];
$PWD=$_POST["password"];
$CPWD=$_POST["cpassword"];
$imagename=$_FILES["img"]["name"];
$imagepath="profilepic\\".$imagename;
move_uploaded_file($_FILES["img"]["tmp_name"],$imagepath);
$con=mysqli_connect("localhost","root","7505233888","ecom4u");
if(!$con)
die("Server could not connected");
else if($PWD==$CPWD)
{
$sqldata="insert into record values('".$N."','".$UN."','".$M."','".$P."','".$PWD."','".$CPWD."','".$imagename."')";
$check=mysqli_query($con,$sqldata);
$imagename=$_FILES["img"]["name"];
$imagepath="profilepic\\".$imagename;
move_uploaded_file($_FILES["img"]["tmp_name"],$imagepath);
if($check!=0)
{
 echo  '<script>alert("Sign up Successful")</script>';
	
}
else
 	echo "Failed To Sign in";
}
else
	echo "Password and confirm password are different";

?>