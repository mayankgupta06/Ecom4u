<?php
$PID=$_POST["Proid"];
$N=$_POST["Name"];
$C=$_POST["Cat"];
$Co=$_POST["Cost"];
$imagename=$_FILES["img"]["name"];
$imagepath="stockitem\\".$imagename;
move_uploaded_file($_FILES["img"]["tmp_name"],$imagepath);


$D=$_POST["Dis"];
$con=mysqli_connect("localhost","root","7505233888","ecom4u");
if(!$con)
die("Server could not connected");
$sqldata="insert into stock values('".$PID."','".$N."','".$C."','".$Co."','".$imagename."','".$D."')";
$check=mysqli_query($con,$sqldata);

$imagename=$_FILES["img"]["name"];
$imagepath="profilepic\\".$imagename;
move_uploaded_file($_FILES["img"]["tmp_name"],$imagepath);
if($check!=0)
{

		header("location:userdash.php");
		
 echo  '<script>alert("Item Added Successfully")</script>';
	
}
else
 	echo "Failed To Add Item";

?>