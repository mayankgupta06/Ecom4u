<html>
<head>

<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap3.3.7/css/bootstrap.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script>
$(document).ready(function(){
	$("#flip").click(function(){
		$("#panel").slideToggle("slow");
	});
	});
</script>
<style>
#panel,#flip{
	padding: 5px;
	margin-left: 20px;
	margin-top: 30px;
	text-align: center;
	width:30%;
	position: relative;
	background-color:#808000;
	border: solid 1px #c3c3c3;
}
#panel{
	margin-top: 0px;
	padding: 20px;
	display: none;
}


 @import url('https://fonts.googleapis.com/css?family=Roboto');

*{
margin: 0;
padding: 0;
box-sizing: border-box;
outline: none;
font-family: 'Roboto',sans-serif;
}

body{
background: url('bg7.jpg') no-repeat;
background-size: cover;
height: 100vh;

}



h1{
color:#ffffff;
}

.wrapper{
position: absolute;
top: 50%;
transform: translateY(-60%);
width: 100%;
padding: 0 20px;
}

.contact-form{
max-width: 550px;
margin: 0 auto;
background: rgba(0,0,0,0.8);
padding: 30px;
border-radius: 7px;
display: flex;
box-shadow: 0 0 10px rgba(0,0,0,0.13);
}

.input-fields{
display: flex;
flex-direction: column;
margin-right: 4%
}

.input-fields,
.msg{
width: 48%
}

.input-fields .input,
.msg textarea{
margin: 10px 0;
background: transparent;
border:0;
border-bottom: 2px solid #c5ecfd;
padding: 10px;
color: #c5ecfd;
width: 100%;
    margin-bottom: 20px;
}

.msg textarea{
height: 212px;
}

::-ms-input-placeholder{
   color: #c5ecfd;
}

.btn{
 background-color: #fe4c50;
    color: #fff;
    border: 1px solid transparent;
    padding: 13px 50px;
    font-size: 16px;
    text-align: center;
    font-weight: 300;
    border-radius: 100px 100px;
    -webkit-transition: all 0.3s ease 0s;
    -moz-transition: all 0.3s ease 0s;
    -o-transition: all 0.3s ease 0s;
    transition: all 0.3s ease 0s
}

.btn:hover {
    background-color: transparent;
    border-color: #fe4c50;
    color: #fe4c50;
}

@media screen and (max-width: 600px){
.contact-form{
flex-direction: column;
}
.msg textarea{
height: 80px;
}
.input-fields,
.msg{
width: 100%;
}
}  

</style>
</head>

<?php

$con=mysqli_connect("localhost","root","7505233888","ecom4u");
if(!$con)
die("Server could not connected");
session_start();
if(isset($_SESSION["ID"]))
{
	$sql="select * from record where uname='".$_SESSION["ID"]."'";
	$rs=mysqli_query($con,$sql);
	$value=mysqli_fetch_assoc($rs);

}
else
{
	header("location:signup.html");
}
?>
<body>
	<div style="top:10px; right: 10px; position: absolute;">
		<button class="btn btn-primary"><a href="logout.php" style="text-decoration: none; color: black;">Logout</a></button></div>
	<div align="center">
<img align="center"src="<?php echo 'profilepic/'.$value['ProfilePic']; ?>" height=200 width=200 border=2 style="border-radius:100px;">

<h1>Welcome:<?php echo $value['name']; ?></h1></div>
<div style="margin-left: 20px;">
	<h3><font color="#241e4e";>Add Item:</font></h3>
</div>




<form action="addstock.php" method="post" enctype="multipart/form-data">
<div class="wrapper" style="position: relative; top: 230px; right: 0px;">
<div class="contact-form">
<div class="input-fields">
<h1>Give Details:</h1>
<input type="number" class="input" placeholder="Product Id" name="Proid">
<input type="text" class="input" placeholder="Product Name" name="Name">
<input type="text" class="input" placeholder="Category" name="Cat">
<input type="number" class="input" placeholder="Cost" name="Cost">
<input type="file" class="input" placeholder="Add Image" name="img">
</div>
<div class="msg">
<textarea placeholder="Product Description" name="Dis"></textarea><br>
<button type="submit" class="button">Submit</button>
</div>
</div>
</div>
</form>





<div style="margin-left: 20px; position: relative;top: 30px;">
	<h3><font color="#241e4e";>Delete Item:</font></h3>
</div>
<div style="position: relative;top: 40px;margin-left: 20px;">
	<form action="delete.php" method="post">
	<input type="text" name="txt1" placeholder="Enter Product ID">
	<input type="submit" class="btn btn-danger" value="Delete">
</form>
</div>

</body>
</html>