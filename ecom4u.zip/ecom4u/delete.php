<?php
session_start();
$pid=$_POST["txt1"];
$con=mysqli_connect("localhost","root","7505233888","ecom4u");
if(!$con)
die("Server could not connected");
$sql="delete from stock where pid=".$pid."";
$check=mysqli_query($con,$sql);
if($check!=0)
 header("location:userdash.php");
else
 echo "Unable to delete";
?>