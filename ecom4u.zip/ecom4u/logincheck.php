<?php
session_start();
$identity=$_POST["id"];
$pass=$_POST["password"];
$con=mysqli_connect("localhost","root","7505233888","ecom4u");
if(!$con)
die("Server could not connected");
$sql="select * from record where uname='".$identity."'";
$rs=mysqli_query($con,$sql);
$value=mysqli_fetch_assoc($rs);
if($value["password"]==$pass)
	{
		$_SESSION["ID"]=$identity;
		
		header("location:userdash.php");
	
	}
else
	echo "<font color='red'>Invalid username or password";
	?> 